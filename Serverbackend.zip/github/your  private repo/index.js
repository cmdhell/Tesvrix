/**
 * ============================================
 * TESVRIX · SECURE PROXY SERVER v4.0.4 (ULTRA ROBUST)
 * WebSocket Screen Streaming Relay
 * ============================================
 */

const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');
const http = require('http');
const { WebSocketServer } = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });

// ======================== ENVIRONMENT CONFIG ========================
const PORT = process.env.PORT || 10000;
const SUPABASE_URL = process.env.SUPABASE_URL || "";
const SUPABASE_KEY = process.env.SUPABASE_KEY || "";
const TG_TOKEN = process.env.TELEGRAM_TOKEN || process.env.TELEGRAM_BOT_TOKEN || "";
const WEB_TOKEN = process.env.WEB_ACCESS_TOKEN || "render web token";
const APP_TOKEN = process.env.APP_ACCESS_TOKEN || "render app token";

const SUPABASE_BASE = SUPABASE_URL.replace(/\/rest\/v1\/?$/, "").replace(/\/$/, "");

// ======================== STREAMING LOGIC ========================
const rooms = new Map(); // device_uuid -> { dashboardClients: Set, appSocket: ws }

wss.on('connection', (ws, req) => {
    let clientType = null;
    let deviceUuid = null;

    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const token = req.headers['x-access-token'] || url.searchParams.get('token');
    const uuid = req.headers['x-device-uuid'];

    console.log(`[DEBUG] New connection attempt. Token: ${token ? 'YES' : 'NO'} | UUID in Header: ${uuid || 'NONE'}`);

    // App Connection Handling (via Headers)
    if (token === APP_TOKEN && uuid) {
        clientType = 'app';
        deviceUuid = uuid;
        if (!rooms.has(deviceUuid)) rooms.set(deviceUuid, { dashboardClients: new Set(), appSocket: null });
        rooms.get(deviceUuid).appSocket = ws;
        console.log(`[AUTH] App authorized for UUID: ${deviceUuid}`);
    }

    ws.on('message', (message) => {
        try {
            const dataStr = message.toString();
            let isJson = false;
            let data = null;

            // 🟢 Try parsing as JSON first (Control Messages)
            try {
                data = JSON.parse(dataStr);
                isJson = true;
            } catch (e) { isJson = false; }

            if (isJson && data) {
                if (data.type === 'dashboard_join') {
                    if (data.token !== WEB_TOKEN) {
                        console.log(`[AUTH] Dashboard login FAILED (Invalid Token)`);
                        return ws.close(4003, "Invalid Token");
                    }
                    clientType = 'dashboard';
                    deviceUuid = data.device_uuid;

                    if (!rooms.has(deviceUuid)) rooms.set(deviceUuid, { dashboardClients: new Set(), appSocket: null });
                    rooms.get(deviceUuid).dashboardClients.add(ws);
                    console.log(`[STREAM] Dashboard joined for ${deviceUuid} (Total: ${rooms.get(deviceUuid).dashboardClients.size})`);
                    return;
                }

                if (clientType === 'app' && deviceUuid) {
                    // Relay JSON from App (Hierarchy/Nodes)
                    const room = rooms.get(deviceUuid);
                    if (room && room.dashboardClients) {
                        room.dashboardClients.forEach(client => {
                            if (client.readyState === 1) client.send(dataStr);
                        });
                    }
                    return;
                }
            }

            // 🟢 If not JSON, handle as Binary Frame (Only from App)
            if (Buffer.isBuffer(message) || (typeof message === 'object')) {
                if (clientType === 'app' && deviceUuid) {
                    const room = rooms.get(deviceUuid);
                    if (room && room.dashboardClients) {
                        room.dashboardClients.forEach(client => {
                            if (client.readyState === 1) client.send(message, { binary: true });
                        });
                    }
                }
            }
        } catch (e) { console.error("[WS ERROR]", e.message); }
    });

    ws.on('close', () => {
        if (deviceUuid && rooms.has(deviceUuid)) {
            const room = rooms.get(deviceUuid);
            if (clientType === 'dashboard') room.dashboardClients.delete(ws);
            if (clientType === 'app') room.appSocket = null;
            if (room.dashboardClients.size === 0 && !room.appSocket) rooms.delete(deviceUuid);
        }
    });
});

// Upgrade HTTP to WS
server.on('upgrade', (request, socket, head) => {
    try {
        const urlObj = new URL(request.url, `http://${request.headers.host}`);

        if (urlObj.pathname === '/stream') {
            // Check headers first, then query string
            let token = request.headers['x-access-token'];
            if (!token) {
                token = urlObj.searchParams.get('token');
            }

            if (token && (token === APP_TOKEN || token === WEB_TOKEN)) {
                wss.handleUpgrade(request, socket, head, (ws) => {
                    wss.emit('connection', ws, request);
                });
                return;
            }

            console.warn(`[WS AUTH FAIL] Path: ${urlObj.pathname} | Token Found: ${token ? "YES" : "NO"} | URL: ${request.url}`);
        }
    } catch (e) {
        console.error("[UPGRADE ERROR]", e.message);
    }

    socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
    socket.destroy();
});

// ======================== MIDDLEWARE ========================
app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.static(__dirname));

app.get('/health', (req, res) => {
    res.json({ status: "online", rooms: rooms.size, timestamp: new Date().toISOString() });
});

const authCheck = (req, res, next) => {
    const token = req.headers['x-access-token'] || req.headers['X-Access-Token'] || req.query.token;
    if (token === WEB_TOKEN || token === APP_TOKEN) return next();
    res.status(403).json({ error: "Access Denied" });
};

// ======================== PROXY ROUTES ========================

app.all('/rest/v1/*', authCheck, async (req, res) => {
    if (!SUPABASE_BASE || !SUPABASE_KEY) return res.status(500).json({ error: "Config missing" });
    try {
        const response = await axios({
            method: req.method,
            url: `${SUPABASE_BASE}${req.originalUrl}`,
            data: req.body,
            headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Prefer': req.headers['prefer'] || 'return=representation', 'Content-Type': 'application/json' },
            timeout: 60000
        });
        res.status(response.status).send(response.data);
    } catch (error) {
        res.status(error.response?.status || 500).send(error.response?.data || { error: error.message });
    }
});

app.post('/tg/send', authCheck, async (req, res) => {
    const { chat_id, text } = req.body;
    if (!TG_TOKEN) return res.status(500).send("TG Token missing");
    try {
        await axios.post(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, { chat_id, text, parse_mode: 'HTML' });
        res.json({ success: true });
    } catch (e) { res.status(500).send("TG fail"); }
});

app.get('/download', authCheck, async (req, res) => {
    const { id, name } = req.query;
    if (!id) return res.status(400).send("Missing ID");
    try {
        const response = await axios.get(`${SUPABASE_BASE}/rest/v1/vault?id=eq.${id}`, { headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` } });
        if (!response.data?.length) return res.status(404).send("Not found");
        let content = response.data[0].content;
        if (content.includes("base64,")) content = content.split("base64,")[1];
        res.setHeader('Content-Type', 'application/octet-stream');
        res.setHeader('Content-Disposition', `attachment; filename="${name || 'file'}"`);
        res.send(Buffer.from(content, 'base64'));
        axios.delete(`${SUPABASE_BASE}/rest/v1/vault?id=eq.${id}`, { headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` } }).catch(e => {});
    } catch (error) { res.status(500).send("Error"); }
});

// ======================== SERVER START ========================
server.listen(PORT, () => {
    console.log(`[TESVRIX] Secure Relay V4.0.4 Active on Port ${PORT}`);
});
